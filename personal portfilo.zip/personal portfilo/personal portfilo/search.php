<?php
require 'db_connect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Messages</title>
    <link rel="stylesheet" href="stylee.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="projects.php">Projects</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <section class="page-header">SEARCH MESSAGES</section>

    <section class="contact-container">
        <div class="contact-form" style="width: 100%;">
            <form method="GET">
                <label for="query">Search by name, email, or subject:</label>
                <input type="text" name="query" id="query" placeholder="Type a keyword..." required>
                <div class="button-container center-button">
                    <button type="submit">Search</button>
                </div>
            </form>
        </div>
    </section>

    <?php
    if (isset($_GET['query'])) {
        $search = "%" . $_GET['query'] . "%";
        $stmt = $conn->prepare("SELECT id, name, email, inquiry, subject, message, submitted_at FROM messages WHERE name LIKE ? OR email LIKE ? OR subject LIKE ?");
        $stmt->bind_param("sss", $search, $search, $search);
        $stmt->execute();
        $result = $stmt->get_result();

        echo "<div class='tables'>";
        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>Name</th><th>Email</th><th>Inquiry</th><th>Subject</th><th>Message</th><th>Date</th><th>Actions</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                echo "<td>" . htmlspecialchars($row['inquiry']) . "</td>";
                echo "<td>" . htmlspecialchars($row['subject']) . "</td>";
                echo "<td>" . htmlspecialchars($row['message']) . "</td>";
                echo "<td>" . $row['submitted_at'] . "</td>";
                echo "<td>
                        <a href='edit_message.php?id=" . $row['id'] . "'>📝 Edit</a> |
                        <a href='delete_message.php?id=" . $row['id'] . "' onclick=\"return confirm('Are you sure?');\">🗑 Delete</a>
                      </td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p> No results found.</p>";
        }
        echo "</div>";

        $stmt->close();
        $conn->close();
    }
    ?>
</body>
</html>

