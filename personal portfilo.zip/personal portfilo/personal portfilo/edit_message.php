<?php
// Connect to the database
require 'db_connect.php';

// === 1. When the user lands on the page with a GET request and 'id' is set ===
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET['id'])) {
    $id = $_GET['id']; // Get the message ID from the URL
    $stmt = $conn->prepare("SELECT * FROM messages WHERE id = ?"); // Prepare SELECT query
    $stmt->bind_param("i", $id); // Bind the ID as an integer
    $stmt->execute();
    $result = $stmt->get_result();
    $message = $result->fetch_assoc(); // Fetch the message record
    $stmt->close();
}

// === 2. When the form is submitted with a POST request ===
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST['id']; // Get the message ID from hidden field
    $subject = $_POST['subject']; // Get the updated subject
    $messageText = $_POST['message']; // Get the updated message

    // Prepare UPDATE query
    $stmt = $conn->prepare("UPDATE messages SET subject = ?, message = ? WHERE id = ?");
    $stmt->bind_param("ssi", $subject, $messageText, $id);

    // Execute update and give feedback
    if ($stmt->execute()) {
        echo "<p style='color: green; text-align:center;'> Message updated successfully. <a href='search.php'>Back to Search</a></p>";
    } else {
        echo "<p style='color: red; text-align:center;'> Update failed: " . $stmt->error . "</p>";
    }

    $stmt->close();
    $conn->close();
}
?>

<?php if (isset($message)) : ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Message</title>
    <link rel="stylesheet" href="stylee.css"> <!-- External styling -->
</head>
<body>
    <!-- Navigation Menu -->
    <header>
        <nav>
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="projects.php">Projects</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </header>

    <!-- Page Title -->
    <section class="page-header">Edit Message</section>

    <!-- Edit Form Section -->
    <section class="contact-container">
        <div class="contact-form" style="width: 100%;">
            <form method="POST">
                <!-- Hidden input to hold the message ID -->
                <input type="hidden" name="id" value="<?= $message['id'] ?>">

                <!-- Subject field -->
                <label for="subject">Subject:</label>
                <input type="text" id="subject" name="subject" value="<?= htmlspecialchars($message['subject']) ?>" required>

                <!-- Message textarea -->
                <label for="message">Message:</label>
                <textarea id="message" name="message" rows="5"><?= htmlspecialchars($message['message']) ?></textarea>

                <!-- Save and Cancel Buttons -->
                <div class="button-container">
                    <button type="submit">💾 Save Changes</button>
                    <a href="search.php" style="padding: 12px 20px; background: #ccc; color: #333; text-decoration: none; border-radius: 8px;">Cancel</a>
                </div>
            </form>
        </div>
    </section>
</body>
</html>
<?php endif; ?>
