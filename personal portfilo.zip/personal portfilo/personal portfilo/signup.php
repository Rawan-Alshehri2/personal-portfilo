<!-- signup.php -->
<?php
// Include the database connection file
require 'db_connect.php';

// Function to check password strength
function strongPassword($pw) {
    return strlen($pw) >= 8 &&          // Minimum 8 characters
           preg_match('/[A-Z]/', $pw) && // At least one uppercase letter
           preg_match('/[0-9]/', $pw) && // At least one number
           preg_match('/[\W_]/', $pw);   // At least one special character
}

// Check if the form was submitted using POST method
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get form inputs
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format. Please try again.";
    }
    // Validate password strength
    elseif (!strongPassword($password)) {
        $error = "Weak password: must include 8+ chars, 1 uppercase, 1 number, 1 special.";
    }
    else {
        // Check if email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // Email already registered
            $error = "Email already registered. <a href='login.php'>Login here</a>";
        } else {
            // Insert the new user into the database
            $stmt->close();
            $hashed = password_hash($password, PASSWORD_DEFAULT); // Hash the password securely
            $stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $email, $hashed);

            if ($stmt->execute()) {
                // Account creation successful
                $success = "Account created successfully! <a href='login.php'>Login</a>";
            } else {
                // Account creation failed
                $error = "Failed to create your account. Please try again later.";
            }
        }

        // Close database resources
        $stmt->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Sign Up</title>
  <!-- Link to external CSS file -->
  <link rel="stylesheet" href="stylee.css">
</head>
<body>
<div class="auth-container">
    <h2>Sign Up</h2>

    <!-- Display error message if there is an error -->
    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

    <!-- Display success message if the account was created -->
    <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>

    <!-- Signup form -->
    <form method="POST">
        <input type="email" name="email" placeholder="Enter your Email" required><br><br>
        <input type="password" name="password" placeholder="Create Password" required><br><br>
        <button type="submit">Create Account</button>
    </form>

    <!-- Link to login page if the user already has an account -->
    <p>Already have an account? <a href="login.php">Login here</a></p>
</div>
</body>
</html>

