<?php
include("db_connect.php");

echo " Connection to the database was successful!";
?>
