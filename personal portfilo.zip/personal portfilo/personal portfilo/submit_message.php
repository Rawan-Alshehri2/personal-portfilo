<?php
// Include the database connection file
require 'db_connect.php'; 

// Check if the form was submitted using POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize form input values
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $inquiry = $_POST['inquiry'];
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);

    // === 1. Check for required fields ===
    if (empty($name) || empty($email) || empty($inquiry) || empty($subject) || empty($message)) {
        die("All fields are required."); // Stop execution if any field is empty
    }

    // === 2. Validate email format ===
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email format."); // Stop execution if email is not valid
    }

    // === 3. Check subject minimum length ===
    if (strlen($subject) < 5) {
        die("Subject must be at least 5 characters."); // Stop execution if subject is too short
    }

    // === 4. Check message maximum length ===
    if (strlen($message) > 500) {
        die("Message must not exceed 500 characters."); // Stop execution if message is too long
    }

    // If all validations pass, insert the data into the database
    $stmt = $conn->prepare("INSERT INTO messages (name, email, inquiry, subject, message) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $name, $email, $inquiry, $subject, $message);

    // Execute the statement and check if it was successful
    if ($stmt->execute()) {
        echo "Message submitted successfully!";
    } else {
        // Display an error if the insertion failed
        echo "Error: " . $stmt->error;
    }

    // Close the prepared statement and database connection
    $stmt->close();
    $conn->close();
}
?>
