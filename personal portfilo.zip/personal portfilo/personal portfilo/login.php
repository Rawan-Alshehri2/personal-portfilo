<?php
// Start the session to manage user login state
session_start();

// Include database connection file
require 'db_connect.php';

// Check if the form was submitted using POST method
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the submitted email and password
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare an SQL statement to select the hashed password for the given email
    $stmt = $conn->prepare("SELECT password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    // Check if the email exists in the database
    if ($stmt->num_rows === 1) {
        // Bind the result to a variable
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        // Verify the submitted password against the hashed password
        if (password_verify($password, $hashed_password)) {
            // Password is correct, save email in session and redirect to index.php
            $_SESSION['email'] = $email;
            header("Location: index.html"); // Redirect to the homepage 
            exit();
        } else {
            // Password is incorrect
            $error = "Incorrect password.";
        }
    } else {
        // Email not found in the database
        $error = "Email not found. <a href='signup.php'>Sign up</a>";
    }

    // Close the statement and database connection
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <!-- Link to external CSS file -->
    <link rel="stylesheet" href="stylee.css">
</head>
<body>
    <!-- Login form container -->
    <div class="auth-container">
        <h2>Login</h2>

        <!-- Display error message if it exists -->
        <?php if (isset($error)) echo "<p style='color: red;'>$error</p>"; ?>

        <!-- Login form -->
        <form method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>

        <!-- Additional links for signup and password reset -->
        <a href="signup.php">Don't have an account? Sign up</a><br>
        <a href="reset_password.php">Forgot password?</a>
    </div>
</body>
</html>
