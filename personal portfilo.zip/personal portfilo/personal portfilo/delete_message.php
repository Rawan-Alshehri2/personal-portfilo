<?php
// Import the database connection settings
require 'db_connect.php';

// Check if 'id' is provided via GET request
if (isset($_GET['id'])) {
    $id = $_GET['id']; // Get the ID of the message to delete

    // Prepare the SQL statement to delete the message safely
    $stmt = $conn->prepare("DELETE FROM messages WHERE id = ?");
    $stmt->bind_param("i", $id); // Bind the 'id' as an integer

    // Execute the delete operation
    if ($stmt->execute()) {
        //  Deletion successful
        echo " Message deleted successfully. <a href='search.php'>Back to Search</a>";
    } else {
        //  Deletion failed
        echo " Failed to delete: " . $stmt->error;
    }

    // Close the prepared statement and database connection
    $stmt->close();
    $conn->close();

} else {
    // If no 'id' provided in the URL
    echo " Invalid request.";
}
?>
