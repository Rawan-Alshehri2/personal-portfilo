<?php
// Include the database connection file
require 'db_connect.php';

// Check if the form is submitted using POST method
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get the submitted email and new password
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    }
    // Validate password strength (at least 8 characters, 1 uppercase letter, 1 number, 1 special character)
    elseif (!preg_match("/^(?=.*[A-Z])(?=.*[0-9])(?=.*[\W_]).{8,}$/", $new_password)) {
        $error = "Weak password.";
    }
    else {
        // Check if the email exists in the users table
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {
            // If email exists, hash the new password
            $stmt->close();
            $hashed = password_hash($new_password, PASSWORD_DEFAULT);

            // Update the password in the database
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
            $stmt->bind_param("ss", $hashed, $email);
            
            if ($stmt->execute()) {
                // Password reset successful
                $success = "Password reset successful. <a href='login.php'>Login</a>";
            } else {
                // Password reset failed
                $error = "Failed to reset password.";
            }
        } else {
            // Email not found
            $error = "Email not found.";
        }

        // Close database resources
        $stmt->close();
        $conn->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reset Password</title>
  <!-- Link to external CSS file -->
  <link rel="stylesheet" href="stylee.css">
</head>
<body>
<div class="auth-container">
    <h2>Reset Password</h2>

    <!-- Display error message if there is an error -->
    <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>

    <!-- Display success message if password reset is successful -->
    <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>

    <!-- Password reset form -->
    <form method="POST">
        <input type="email" name="email" placeholder="Enter your Email" required><br><br>
        <input type="password" name="new_password" placeholder="New Password" required><br><br>
        <button type="submit">Reset Password</button>
    </form>

    <!-- Link to go back to login page -->
    <p>Remembered it? <a href="login.php">Back to login</a></p>
</div>
</body>
</html>
